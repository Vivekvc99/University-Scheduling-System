class Admin < ApplicationRecord
    self.table_name = "admins"
end