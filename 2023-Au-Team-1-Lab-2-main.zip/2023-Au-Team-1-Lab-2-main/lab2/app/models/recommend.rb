class Recommend < ApplicationRecord
    self.table_name = "recommends"
end