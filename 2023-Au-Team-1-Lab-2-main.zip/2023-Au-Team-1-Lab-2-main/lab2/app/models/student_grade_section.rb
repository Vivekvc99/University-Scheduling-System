class Student_grade_section < ApplicationRecord
    self.table_name = "student_grade_sections"
end