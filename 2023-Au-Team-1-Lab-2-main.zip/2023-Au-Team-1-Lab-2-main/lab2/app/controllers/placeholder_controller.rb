class PlaceholderController < ApplicationController
  def welcome
  end
end
