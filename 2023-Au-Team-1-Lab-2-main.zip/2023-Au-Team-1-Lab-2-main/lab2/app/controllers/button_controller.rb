class ButtonController < ApplicationController
    def addCourses

    end
end
